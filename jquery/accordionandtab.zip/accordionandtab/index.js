$(document).ready(function(){
    $("#accordion").accordion();
    $("#tabs").tabs();
});
